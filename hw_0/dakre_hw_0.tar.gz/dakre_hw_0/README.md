# HW #0 Run Instructions
1) Open project with hw_0.xpr (in this instance create new project then add all verilog sources)
2) Run simulation with default procedural module and test bench set to top source
3) Change top source to structural module and testbench and rerun simulation
4) Compare results and inspect that they are the same

NOTE: Test benches are the same, just instantiations are differnet between the two

## Test bench outputs:

### Structural design

r0 = 0
r0 = 0
r0 = 0
r0 = 0
r0 = 0
r0 = 1
r0 = 1
r0 = 1
r0 = 0
r0 = 1
r0 = 1
r0 = 1
r0 = 0
r0 = 1
r0 = 1
r0 = 1

### Procedural design

r0 = 0
r0 = 0
r0 = 0
r0 = 0
r0 = 0
r0 = 1
r0 = 1
r0 = 1
r0 = 0
r0 = 1
r0 = 1
r0 = 1
r0 = 0
r0 = 1
r0 = 1
r0 = 1
