/* Author: David Akre
 * Date: 10/7/17
 * Description: Assignment 2 - dpgen interface
 * - This interface is used as an interface for dpgen
 *
 */

#pragma once

#include <HLSEngine.h>

HLSEngine* engine;
