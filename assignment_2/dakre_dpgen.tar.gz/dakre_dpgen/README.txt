Group:
David Akre (netid: dakre)

Course:
ECE: 574a Computer Aided Logic Design

Description:
The program has the capability of performing high level synthesis on
a behavioral netlist file per the rubrics specs. The program will
read that input file as the first argument, parse its contents,
and generate synthesizable verilog code per the second argument's
file name. After this is completed, the program will compute the
critical path for the synthesized circuit utilizing the data
path component library with signed/unsigned components.

Contribution:
Completed by myself


